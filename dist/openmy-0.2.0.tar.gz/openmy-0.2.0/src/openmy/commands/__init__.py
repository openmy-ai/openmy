"""OpenMy CLI command implementations."""
