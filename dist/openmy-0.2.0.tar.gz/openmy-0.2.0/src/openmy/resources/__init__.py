"""Bundled resource files."""
