"""Scene distillation services."""
