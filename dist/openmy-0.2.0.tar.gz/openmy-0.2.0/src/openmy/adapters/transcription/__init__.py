"""Transcription adapters."""
