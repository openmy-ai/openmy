"""Service layer for OpenMy."""
