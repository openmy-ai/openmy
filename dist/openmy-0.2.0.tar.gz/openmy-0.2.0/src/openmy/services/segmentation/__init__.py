"""Scene segmentation services."""
