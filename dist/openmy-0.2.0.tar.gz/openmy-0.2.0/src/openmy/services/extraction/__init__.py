"""Structured extraction services."""
