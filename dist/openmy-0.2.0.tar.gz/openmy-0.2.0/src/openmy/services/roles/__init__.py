"""Role resolution services."""
