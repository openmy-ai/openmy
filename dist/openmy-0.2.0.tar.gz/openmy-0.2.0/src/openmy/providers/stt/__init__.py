"""Speech-to-text providers."""
